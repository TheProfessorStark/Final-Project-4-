﻿using System.Windows.Forms;

namespace WindowsFormsApp2
{
    partial class mainhead
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.add_prof = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btn_addstudent = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.edit_prof = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_editstudent = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btn_studtstat = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_ditstudent = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_editclass = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_addclass = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.panel9);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(283, 753);
            this.panel1.TabIndex = 0;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.add_prof);
            this.panel9.Location = new System.Drawing.Point(12, 668);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(251, 76);
            this.panel9.TabIndex = 1;
            // 
            // add_prof
            // 
            this.add_prof.Location = new System.Drawing.Point(-9, -43);
            this.add_prof.Name = "add_prof";
            this.add_prof.Size = new System.Drawing.Size(288, 155);
            this.add_prof.TabIndex = 2;
            this.add_prof.Text = "افون استاد";
            this.add_prof.UseVisualStyleBackColor = true;
            this.add_prof.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btn_addstudent);
            this.panel8.Location = new System.Drawing.Point(12, 586);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(251, 76);
            this.panel8.TabIndex = 1;
            // 
            // btn_addstudent
            // 
            this.btn_addstudent.Location = new System.Drawing.Point(-9, -43);
            this.btn_addstudent.Name = "btn_addstudent";
            this.btn_addstudent.Size = new System.Drawing.Size(288, 155);
            this.btn_addstudent.TabIndex = 2;
            this.btn_addstudent.Text = "افزودن دانشجو";
            this.btn_addstudent.UseVisualStyleBackColor = true;
            this.btn_addstudent.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.edit_prof);
            this.panel7.Location = new System.Drawing.Point(12, 504);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(251, 76);
            this.panel7.TabIndex = 1;
            // 
            // edit_prof
            // 
            this.edit_prof.Location = new System.Drawing.Point(-9, -43);
            this.edit_prof.Name = "edit_prof";
            this.edit_prof.Size = new System.Drawing.Size(288, 155);
            this.edit_prof.TabIndex = 2;
            this.edit_prof.Text = "ویرایش اساتید";
            this.edit_prof.UseVisualStyleBackColor = true;
            this.edit_prof.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btn_editstudent);
            this.panel6.Location = new System.Drawing.Point(12, 422);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(251, 76);
            this.panel6.TabIndex = 1;
            // 
            // btn_editstudent
            // 
            this.btn_editstudent.Location = new System.Drawing.Point(-9, -43);
            this.btn_editstudent.Name = "btn_editstudent";
            this.btn_editstudent.Size = new System.Drawing.Size(288, 155);
            this.btn_editstudent.TabIndex = 2;
            this.btn_editstudent.Text = "ویرایش لیست دانشجویان";
            this.btn_editstudent.UseVisualStyleBackColor = true;
            this.btn_editstudent.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btn_studtstat);
            this.panel5.Location = new System.Drawing.Point(12, 340);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(251, 76);
            this.panel5.TabIndex = 1;
            // 
            // btn_studtstat
            // 
            this.btn_studtstat.Location = new System.Drawing.Point(-17, -40);
            this.btn_studtstat.Name = "btn_studtstat";
            this.btn_studtstat.Size = new System.Drawing.Size(288, 155);
            this.btn_studtstat.TabIndex = 2;
            this.btn_studtstat.Text = "کارنامه دانشجو";
            this.btn_studtstat.UseVisualStyleBackColor = true;
            this.btn_studtstat.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btn_ditstudent);
            this.panel4.Location = new System.Drawing.Point(12, 258);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(251, 76);
            this.panel4.TabIndex = 1;
            // 
            // btn_ditstudent
            // 
            this.btn_ditstudent.Location = new System.Drawing.Point(-9, -43);
            this.btn_ditstudent.Name = "btn_ditstudent";
            this.btn_ditstudent.Size = new System.Drawing.Size(288, 155);
            this.btn_ditstudent.TabIndex = 2;
            this.btn_ditstudent.Text = "ویرایش دروس دانشجو";
            this.btn_ditstudent.UseVisualStyleBackColor = true;
            this.btn_ditstudent.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btn_editclass);
            this.panel3.Location = new System.Drawing.Point(12, 176);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(251, 76);
            this.panel3.TabIndex = 1;
            // 
            // btn_editclass
            // 
            this.btn_editclass.Location = new System.Drawing.Point(-9, -43);
            this.btn_editclass.Name = "btn_editclass";
            this.btn_editclass.Size = new System.Drawing.Size(288, 155);
            this.btn_editclass.TabIndex = 2;
            this.btn_editclass.Text = "ویرایش دروس ارایه شده";
            this.btn_editclass.UseVisualStyleBackColor = true;
            this.btn_editclass.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_addclass);
            this.panel2.Location = new System.Drawing.Point(12, 94);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(251, 76);
            this.panel2.TabIndex = 1;
            // 
            // btn_addclass
            // 
            this.btn_addclass.Location = new System.Drawing.Point(-9, -43);
            this.btn_addclass.Name = "btn_addclass";
            this.btn_addclass.Size = new System.Drawing.Size(288, 155);
            this.btn_addclass.TabIndex = 2;
            this.btn_addclass.Text = "افزودن درس جدید";
            this.btn_addclass.UseVisualStyleBackColor = true;
            this.btn_addclass.Click += new System.EventHandler(this.button1_Click);
            // 
            // mainhead
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1263, 755);
            this.Controls.Add(this.panel1);
            this.Name = "mainhead";
            this.Text = "main head";
            this.panel1.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Button btn_addclass;
        private Panel panel3;
        private Button btn_editclass;
        private Panel panel4;
        private Button btn_ditstudent;
        private Panel panel5;
        private Button btn_studtstat;
        private Panel panel6;
        private Button btn_editstudent;
        private Panel panel7;
        private Button edit_prof;
        private Panel panel8;
        private Button btn_addstudent;
        private Panel panel9;
        private Button add_prof;
    }
}
﻿namespace WindowsFormsApp2
{
    partial class txtLessonDay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLessonCode = new System.Windows.Forms.TextBox();
            this.txtLessonName = new System.Windows.Forms.TextBox();
            this.txtUnitNumber = new System.Windows.Forms.TextBox();
            this.txtStartClass = new System.Windows.Forms.TextBox();
            this.txtFinalExamDate = new System.Windows.Forms.TextBox();
            this.txtTeacher = new System.Windows.Forms.TextBox();
            this.txtLDay = new System.Windows.Forms.TextBox();
            this.txtLessonTime = new System.Windows.Forms.TextBox();
            this.btnEnter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtLessonCode
            // 
            this.txtLessonCode.Location = new System.Drawing.Point(565, 112);
            this.txtLessonCode.Name = "txtLessonCode";
            this.txtLessonCode.Size = new System.Drawing.Size(100, 20);
            this.txtLessonCode.TabIndex = 0;
            // 
            // txtLessonName
            // 
            this.txtLessonName.Location = new System.Drawing.Point(565, 239);
            this.txtLessonName.Name = "txtLessonName";
            this.txtLessonName.Size = new System.Drawing.Size(100, 20);
            this.txtLessonName.TabIndex = 1;
            // 
            // txtUnitNumber
            // 
            this.txtUnitNumber.Location = new System.Drawing.Point(565, 341);
            this.txtUnitNumber.Name = "txtUnitNumber";
            this.txtUnitNumber.Size = new System.Drawing.Size(100, 20);
            this.txtUnitNumber.TabIndex = 2;
            // 
            // txtStartClass
            // 
            this.txtStartClass.Location = new System.Drawing.Point(565, 437);
            this.txtStartClass.Name = "txtStartClass";
            this.txtStartClass.Size = new System.Drawing.Size(100, 20);
            this.txtStartClass.TabIndex = 3;
            // 
            // txtFinalExamDate
            // 
            this.txtFinalExamDate.Location = new System.Drawing.Point(360, 112);
            this.txtFinalExamDate.Name = "txtFinalExamDate";
            this.txtFinalExamDate.Size = new System.Drawing.Size(100, 20);
            this.txtFinalExamDate.TabIndex = 4;
            // 
            // txtTeacher
            // 
            this.txtTeacher.Location = new System.Drawing.Point(360, 239);
            this.txtTeacher.Name = "txtTeacher";
            this.txtTeacher.Size = new System.Drawing.Size(100, 20);
            this.txtTeacher.TabIndex = 5;
            // 
            // txtLDay
            // 
            this.txtLDay.Location = new System.Drawing.Point(360, 341);
            this.txtLDay.Name = "txtLDay";
            this.txtLDay.Size = new System.Drawing.Size(100, 20);
            this.txtLDay.TabIndex = 6;
            // 
            // txtLessonTime
            // 
            this.txtLessonTime.Location = new System.Drawing.Point(360, 437);
            this.txtLessonTime.Name = "txtLessonTime";
            this.txtLessonTime.Size = new System.Drawing.Size(100, 20);
            this.txtLessonTime.TabIndex = 7;
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(456, 537);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(87, 35);
            this.btnEnter.TabIndex = 8;
            this.btnEnter.Text = "ثبت";
            this.btnEnter.UseVisualStyleBackColor = true;
            // 
            // txtLessonDay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 661);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.txtLessonTime);
            this.Controls.Add(this.txtLDay);
            this.Controls.Add(this.txtTeacher);
            this.Controls.Add(this.txtFinalExamDate);
            this.Controls.Add(this.txtStartClass);
            this.Controls.Add(this.txtUnitNumber);
            this.Controls.Add(this.txtLessonName);
            this.Controls.Add(this.txtLessonCode);
            this.Name = "txtLessonDay";
            this.Text = "افزودن درس";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtLessonCode;
        private System.Windows.Forms.TextBox txtLessonName;
        private System.Windows.Forms.TextBox txtUnitNumber;
        private System.Windows.Forms.TextBox txtStartClass;
        private System.Windows.Forms.TextBox txtFinalExamDate;
        private System.Windows.Forms.TextBox txtTeacher;
        private System.Windows.Forms.TextBox txtLDay;
        private System.Windows.Forms.TextBox txtLessonTime;
        private System.Windows.Forms.Button btnEnter;
    }
}
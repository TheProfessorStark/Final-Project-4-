﻿namespace WindowsFormsApp2
{
    partial class HeadAddStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEnter = new System.Windows.Forms.Button();
            this.txtAdress = new System.Windows.Forms.TextBox();
            this.txtTell = new System.Windows.Forms.TextBox();
            this.txtTerm = new System.Windows.Forms.TextBox();
            this.txtField = new System.Windows.Forms.TextBox();
            this.txtBirthDate = new System.Windows.Forms.TextBox();
            this.txtEnterDate = new System.Windows.Forms.TextBox();
            this.txtNationalCode = new System.Windows.Forms.TextBox();
            this.txtFatherName = new System.Windows.Forms.TextBox();
            this.txtStudentCode = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(417, 560);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(75, 23);
            this.btnEnter.TabIndex = 22;
            this.btnEnter.Text = "ثبت";
            this.btnEnter.UseVisualStyleBackColor = true;
            // 
            // txtAdress
            // 
            this.txtAdress.Location = new System.Drawing.Point(210, 408);
            this.txtAdress.Multiline = true;
            this.txtAdress.Name = "txtAdress";
            this.txtAdress.Size = new System.Drawing.Size(464, 112);
            this.txtAdress.TabIndex = 21;
            // 
            // txtTell
            // 
            this.txtTell.Location = new System.Drawing.Point(222, 318);
            this.txtTell.Name = "txtTell";
            this.txtTell.Size = new System.Drawing.Size(166, 20);
            this.txtTell.TabIndex = 20;
            // 
            // txtTerm
            // 
            this.txtTerm.Location = new System.Drawing.Point(222, 234);
            this.txtTerm.Name = "txtTerm";
            this.txtTerm.Size = new System.Drawing.Size(166, 20);
            this.txtTerm.TabIndex = 19;
            // 
            // txtField
            // 
            this.txtField.Location = new System.Drawing.Point(222, 176);
            this.txtField.Name = "txtField";
            this.txtField.Size = new System.Drawing.Size(166, 20);
            this.txtField.TabIndex = 18;
            // 
            // txtBirthDate
            // 
            this.txtBirthDate.Location = new System.Drawing.Point(222, 78);
            this.txtBirthDate.Name = "txtBirthDate";
            this.txtBirthDate.Size = new System.Drawing.Size(166, 20);
            this.txtBirthDate.TabIndex = 16;
            // 
            // txtEnterDate
            // 
            this.txtEnterDate.Location = new System.Drawing.Point(222, 124);
            this.txtEnterDate.Name = "txtEnterDate";
            this.txtEnterDate.Size = new System.Drawing.Size(166, 20);
            this.txtEnterDate.TabIndex = 17;
            // 
            // txtNationalCode
            // 
            this.txtNationalCode.Location = new System.Drawing.Point(508, 306);
            this.txtNationalCode.Name = "txtNationalCode";
            this.txtNationalCode.Size = new System.Drawing.Size(166, 20);
            this.txtNationalCode.TabIndex = 15;
            // 
            // txtFatherName
            // 
            this.txtFatherName.Location = new System.Drawing.Point(508, 234);
            this.txtFatherName.Name = "txtFatherName";
            this.txtFatherName.Size = new System.Drawing.Size(166, 20);
            this.txtFatherName.TabIndex = 14;
            // 
            // txtStudentCode
            // 
            this.txtStudentCode.Location = new System.Drawing.Point(508, 78);
            this.txtStudentCode.Name = "txtStudentCode";
            this.txtStudentCode.Size = new System.Drawing.Size(166, 20);
            this.txtStudentCode.TabIndex = 13;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(508, 176);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(166, 20);
            this.txtLastName.TabIndex = 12;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(508, 124);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(166, 20);
            this.txtName.TabIndex = 11;
            // 
            // HeadAddStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 661);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.txtAdress);
            this.Controls.Add(this.txtTell);
            this.Controls.Add(this.txtTerm);
            this.Controls.Add(this.txtField);
            this.Controls.Add(this.txtBirthDate);
            this.Controls.Add(this.txtEnterDate);
            this.Controls.Add(this.txtNationalCode);
            this.Controls.Add(this.txtFatherName);
            this.Controls.Add(this.txtStudentCode);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtName);
            this.Name = "HeadAddStudent";
            this.ShowIcon = false;
            this.Text = "افزودن استاد جدید";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.TextBox txtAdress;
        private System.Windows.Forms.TextBox txtTell;
        private System.Windows.Forms.TextBox txtTerm;
        private System.Windows.Forms.TextBox txtField;
        private System.Windows.Forms.TextBox txtBirthDate;
        private System.Windows.Forms.TextBox txtEnterDate;
        private System.Windows.Forms.TextBox txtNationalCode;
        private System.Windows.Forms.TextBox txtFatherName;
        private System.Windows.Forms.TextBox txtStudentCode;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtName;
    }
}
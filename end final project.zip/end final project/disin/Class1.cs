﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace disin
{
    internal class Class1
    {
        public static int CurrentId;
        public static string CurrentName;
    }
}

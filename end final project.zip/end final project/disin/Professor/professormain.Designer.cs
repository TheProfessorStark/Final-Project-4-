﻿using System.Windows.Forms;

namespace WindowsFormsApp2
{
    partial class professormain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(professormain));
            this.panel1 = new System.Windows.Forms.Panel();
            this.paneld4 = new System.Windows.Forms.Panel();
            this.paneld2 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.btn_editstudent = new System.Windows.Forms.Button();
            this.paneld1 = new System.Windows.Forms.Panel();
            this.btn_addsub = new System.Windows.Forms.Button();
            this.btnd_editsub = new System.Windows.Forms.Button();
            this.panelcontainer = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.paneld2.SuspendLayout();
            this.paneld1.SuspendLayout();
            this.panelcontainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.panel1.Controls.Add(this.paneld4);
            this.panel1.Controls.Add(this.paneld2);
            this.panel1.Controls.Add(this.btn_editstudent);
            this.panel1.Controls.Add(this.paneld1);
            this.panel1.Controls.Add(this.btnd_editsub);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(0, 25, 0, 0);
            this.panel1.Size = new System.Drawing.Size(213, 523);
            this.panel1.TabIndex = 0;
            // 
            // paneld4
            // 
            this.paneld4.AutoSize = true;
            this.paneld4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.paneld4.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneld4.Location = new System.Drawing.Point(0, 181);
            this.paneld4.Margin = new System.Windows.Forms.Padding(2);
            this.paneld4.Name = "paneld4";
            this.paneld4.Size = new System.Drawing.Size(213, 0);
            this.paneld4.TabIndex = 7;
            this.paneld4.Visible = false;
            // 
            // paneld2
            // 
            this.paneld2.AutoSize = true;
            this.paneld2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.paneld2.Controls.Add(this.button8);
            this.paneld2.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneld2.Location = new System.Drawing.Point(0, 152);
            this.paneld2.Margin = new System.Windows.Forms.Padding(2);
            this.paneld2.Name = "paneld2";
            this.paneld2.Size = new System.Drawing.Size(213, 29);
            this.paneld2.TabIndex = 4;
            // 
            // button8
            // 
            this.button8.AutoSize = true;
            this.button8.Dock = System.Windows.Forms.DockStyle.Top;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button8.Location = new System.Drawing.Point(0, 0);
            this.button8.Margin = new System.Windows.Forms.Padding(2);
            this.button8.Name = "button8";
            this.button8.Padding = new System.Windows.Forms.Padding(26, 0, 0, 0);
            this.button8.Size = new System.Drawing.Size(213, 29);
            this.button8.TabIndex = 1;
            this.button8.Text = "افزودن و ویرایش نمره دانشجویان";
            this.button8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // btn_editstudent
            // 
            this.btn_editstudent.AutoSize = true;
            this.btn_editstudent.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_editstudent.FlatAppearance.BorderSize = 0;
            this.btn_editstudent.FlatAppearance.MouseOverBackColor = System.Drawing.Color.BlueViolet;
            this.btn_editstudent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_editstudent.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_editstudent.Location = new System.Drawing.Point(0, 103);
            this.btn_editstudent.Margin = new System.Windows.Forms.Padding(5);
            this.btn_editstudent.Name = "btn_editstudent";
            this.btn_editstudent.Padding = new System.Windows.Forms.Padding(10);
            this.btn_editstudent.Size = new System.Drawing.Size(213, 49);
            this.btn_editstudent.TabIndex = 3;
            this.btn_editstudent.Text = "مدیریت دانشجویان";
            this.btn_editstudent.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_editstudent.UseVisualStyleBackColor = true;
            this.btn_editstudent.Click += new System.EventHandler(this.btn_editstudent_Click);
            // 
            // paneld1
            // 
            this.paneld1.AutoSize = true;
            this.paneld1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(32)))), ((int)(((byte)(39)))));
            this.paneld1.Controls.Add(this.btn_addsub);
            this.paneld1.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneld1.Location = new System.Drawing.Point(0, 74);
            this.paneld1.Margin = new System.Windows.Forms.Padding(2);
            this.paneld1.Name = "paneld1";
            this.paneld1.Size = new System.Drawing.Size(213, 29);
            this.paneld1.TabIndex = 2;
            // 
            // btn_addsub
            // 
            this.btn_addsub.AutoSize = true;
            this.btn_addsub.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_addsub.FlatAppearance.BorderSize = 0;
            this.btn_addsub.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btn_addsub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_addsub.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btn_addsub.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn_addsub.Location = new System.Drawing.Point(0, 0);
            this.btn_addsub.Margin = new System.Windows.Forms.Padding(5);
            this.btn_addsub.Name = "btn_addsub";
            this.btn_addsub.Padding = new System.Windows.Forms.Padding(26, 0, 0, 0);
            this.btn_addsub.Size = new System.Drawing.Size(213, 29);
            this.btn_addsub.TabIndex = 0;
            this.btn_addsub.Text = "افزودن و ویرایش ارائه دروس ";
            this.btn_addsub.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_addsub.UseVisualStyleBackColor = true;
            this.btn_addsub.Click += new System.EventHandler(this.btn_addsub_Click);
            // 
            // btnd_editsub
            // 
            this.btnd_editsub.AutoSize = true;
            this.btnd_editsub.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnd_editsub.FlatAppearance.BorderSize = 0;
            this.btnd_editsub.FlatAppearance.MouseOverBackColor = System.Drawing.Color.BlueViolet;
            this.btnd_editsub.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnd_editsub.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnd_editsub.Location = new System.Drawing.Point(0, 25);
            this.btnd_editsub.Margin = new System.Windows.Forms.Padding(5);
            this.btnd_editsub.Name = "btnd_editsub";
            this.btnd_editsub.Padding = new System.Windows.Forms.Padding(10);
            this.btnd_editsub.Size = new System.Drawing.Size(213, 49);
            this.btnd_editsub.TabIndex = 1;
            this.btnd_editsub.Text = "مدیریت دروس";
            this.btnd_editsub.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnd_editsub.UseVisualStyleBackColor = true;
            this.btnd_editsub.Click += new System.EventHandler(this.btnd_editsub_Click);
            // 
            // panelcontainer
            // 
            this.panelcontainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.panelcontainer.Controls.Add(this.pictureBox2);
            this.panelcontainer.Controls.Add(this.pictureBox1);
            this.panelcontainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelcontainer.Location = new System.Drawing.Point(213, 0);
            this.panelcontainer.Margin = new System.Windows.Forms.Padding(2);
            this.panelcontainer.Name = "panelcontainer";
            this.panelcontainer.Size = new System.Drawing.Size(712, 523);
            this.panelcontainer.TabIndex = 2;
            this.panelcontainer.Paint += new System.Windows.Forms.PaintEventHandler(this.panelcontainer_Paint);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(-5, 7);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(29, 29);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(188, 97);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(300, 300);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // professormain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(925, 523);
            this.Controls.Add(this.panelcontainer);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(941, 561);
            this.Name = "professormain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "صفحه استاد";
            this.Load += new System.EventHandler(this.mainhead_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.paneld2.ResumeLayout(false);
            this.paneld2.PerformLayout();
            this.paneld1.ResumeLayout(false);
            this.paneld1.PerformLayout();
            this.panelcontainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private Panel paneld1;
        private Button btn_addsub;
        private Button btnd_editsub;
        private Panel paneld2;
        private Button button8;
        private Button btn_editstudent;
        private Panel panelcontainer;
        private Panel panel4;
        private Button button10;
        private Button button1;
        private PictureBox pictureBox1;
        private Panel paneld4;
        private PictureBox pictureBox2;
    }
}
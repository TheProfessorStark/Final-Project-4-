﻿using disin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{
	public partial class ProfessorEnterScore : Form
	{
        public SqlConnection sqlcon;
        public SqlDataAdapter adapt;
        public DataTable dt;
        public BindingSource bs;
        public SqlCommand cmd;
        public SqlDataReader dr;
        public ProfessorEnterScore()
		{
			InitializeComponent();
            customizeDesing();

        }
        private void customizeDesing()
        {
            panelb.Visible = false;
            panelu.Visible = false;
            
        }    

        private void Form4_Load(object sender, EventArgs e)
		{
            // TODO: This line of code loads data into the 'uniWebDataSet5.StudentSubSelected' table. You can move, or remove it, as needed.
            this.studentSubSelectedTableAdapter.Fill(this.uniWebDataSet5.StudentSubSelected);
            sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
            sqlcon.Open();
            RefreshDatagridview(null);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (panelu.Visible == false)
                panelu.Visible = true;
            else
                panelu.Visible = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if(panelb.Visible == false)
                panelb.Visible = true;
            else
                panelb.Visible = false;
        }

        private DataRow getrow()
        {
            if (bs.Current != null)
            {
                return ((DataRowView)bs.Current).Row;
            }
            else
            {
                return null;
            }


        }

        public void RefreshDatagridview(string SearchText)
        {
            if (SearchText == null)
            {
                adapt = new SqlDataAdapter("select * from StudentSubSelected where Teacher_Present_ID='" +Convert.ToInt32( Class1.CurrentId)+"'", sqlcon);
                dt = new DataTable();
                adapt.Fill(dt);
                bs = new BindingSource();             
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
            }
            else
            {
                adapt = new SqlDataAdapter("select * from StudentSubSelected where Teacher_Present_ID='" +Convert.ToInt32( Class1.CurrentId)+"'and Student_Id like'" + SearchText+"%'", sqlcon);
                dt = new DataTable();
                adapt.Fill(dt);
                bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
            }

            if (dt.Rows.Count > 0)
                dataGridView1.Visible = true;
            else
                dataGridView1.Visible = false;
        }

        private void txtSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text == "جستجو : شماره دانشجویی")
                txtSearch.Text = null;
        }

        private void txtSearch_Leave(object sender, EventArgs e)
        {
            if (txtSearch.Text == "")
            {
                txtSearch.Text = "جستجو : شماره دانشجویی";
                RefreshDatagridview(null);
            }
            //event Search_Leave;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            RefreshDatagridview(txtSearch.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            if (resualt == DialogResult.OK)
            {
                DataRow crow = getrow();
                int csubject = Convert.ToInt32(crow["Subject_Id"]);
                int cstudentid = Convert.ToInt32(crow["Student_Id"]);
                SqlCommand cmd = new SqlCommand("update StudentSubSelected set Point= null WHERE Student_Id ='" + cstudentid + "'and Subject_Id='" + csubject + "'", sqlcon);
                cmd.ExecuteNonQuery();
                RefreshDatagridview(null);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DataRow crow = getrow();
            if (textBox2.Text!= "...نمره را وارد کنید")
            {
                DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                if (resualt == DialogResult.OK)
                {
                    int csubject = Convert.ToInt32(crow["Subject_Id"]);
                    int cstudentid = Convert.ToInt32(crow["Student_Id"]);
                    SqlCommand cmd = new SqlCommand("update StudentSubSelected set Point='" + textBox2.Text + "'WHERE Student_Id ='" + cstudentid + "'and Subject_Id='" + csubject + "'", sqlcon);
                    cmd.ExecuteNonQuery();
                    RefreshDatagridview(null);
                }
                else if (resualt == DialogResult.Cancel)
                {
                    textBox2.Text = "...نمره را وارد کنید";
                }

            }
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            DataRow crow = getrow();
            textBox2.Text = crow["Point"].ToString();
        }

        private void txtSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Back )
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back || e.KeyChar == '.')
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {

                    button3_Click(sender,e);
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "...نمره را وارد کنید")
            {
                textBox2.Text = "";
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "...نمره را وارد کنید";
            }
        }
    }
}

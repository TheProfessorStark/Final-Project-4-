﻿using System.Windows.Forms;

namespace disin.Head
{
    partial class karnameds
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.studentSubSelectedBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.uniWebDataSet5 = new disin.UniWebDataSet5();
            this.button4 = new System.Windows.Forms.Button();
            this.studentSubSelectedTableAdapter = new disin.UniWebDataSet5TableAdapters.StudentSubSelectedTableAdapter();
            this.studentIdDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subjectIdDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subjectNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subjectUnitDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subjectTeacherDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pointDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subPresentIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teacherPresentIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentSubSelectedBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniWebDataSet5)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(30)))), ((int)(((byte)(50)))));
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.button4, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(854, 545);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.DarkCyan;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.DarkCyan;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.studentIdDataGridViewTextBoxColumn1,
            this.subjectIdDataGridViewTextBoxColumn1,
            this.subjectNameDataGridViewTextBoxColumn1,
            this.subjectUnitDataGridViewTextBoxColumn1,
            this.subjectTeacherDataGridViewTextBoxColumn1,
            this.pointDataGridViewTextBoxColumn1,
            this.subPresentIDDataGridViewTextBoxColumn1,
            this.teacherPresentIDDataGridViewTextBoxColumn1});
            this.dataGridView1.DataSource = this.studentSubSelectedBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.DarkCyan;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(17, 39);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.DarkCyan;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.DarkCyan;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.ShowCellErrors = false;
            this.dataGridView1.ShowCellToolTips = false;
            this.dataGridView1.ShowEditingIcon = false;
            this.dataGridView1.ShowRowErrors = false;
            this.dataGridView1.Size = new System.Drawing.Size(820, 447);
            this.dataGridView1.TabIndex = 0;
            // 
            // studentSubSelectedBindingSource
            // 
            this.studentSubSelectedBindingSource.DataMember = "StudentSubSelected";
            this.studentSubSelectedBindingSource.DataSource = this.uniWebDataSet5;
            // 
            // uniWebDataSet5
            // 
            this.uniWebDataSet5.DataSetName = "UniWebDataSet5";
            this.uniWebDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button4
            // 
            this.button4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button4.Location = new System.Drawing.Point(17, 2);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(820, 33);
            this.button4.TabIndex = 2;
            this.button4.Text = "کارنامه دانشجویان";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // studentSubSelectedTableAdapter
            // 
            this.studentSubSelectedTableAdapter.ClearBeforeFill = true;
            // 
            // studentIdDataGridViewTextBoxColumn1
            // 
            this.studentIdDataGridViewTextBoxColumn1.DataPropertyName = "Student_Id";
            this.studentIdDataGridViewTextBoxColumn1.HeaderText = "شماره دانشجویی :";
            this.studentIdDataGridViewTextBoxColumn1.Name = "studentIdDataGridViewTextBoxColumn1";
            this.studentIdDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // subjectIdDataGridViewTextBoxColumn1
            // 
            this.subjectIdDataGridViewTextBoxColumn1.DataPropertyName = "Subject_Id";
            this.subjectIdDataGridViewTextBoxColumn1.HeaderText = "شماره درس :";
            this.subjectIdDataGridViewTextBoxColumn1.Name = "subjectIdDataGridViewTextBoxColumn1";
            this.subjectIdDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // subjectNameDataGridViewTextBoxColumn1
            // 
            this.subjectNameDataGridViewTextBoxColumn1.DataPropertyName = "Subject_Name";
            this.subjectNameDataGridViewTextBoxColumn1.HeaderText = "اسم درس :";
            this.subjectNameDataGridViewTextBoxColumn1.Name = "subjectNameDataGridViewTextBoxColumn1";
            this.subjectNameDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // subjectUnitDataGridViewTextBoxColumn1
            // 
            this.subjectUnitDataGridViewTextBoxColumn1.DataPropertyName = "subject_Unit";
            this.subjectUnitDataGridViewTextBoxColumn1.HeaderText = "تعداد واحد :";
            this.subjectUnitDataGridViewTextBoxColumn1.Name = "subjectUnitDataGridViewTextBoxColumn1";
            this.subjectUnitDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // subjectTeacherDataGridViewTextBoxColumn1
            // 
            this.subjectTeacherDataGridViewTextBoxColumn1.DataPropertyName = "Subject_Teacher";
            this.subjectTeacherDataGridViewTextBoxColumn1.HeaderText = "استاد درس :";
            this.subjectTeacherDataGridViewTextBoxColumn1.Name = "subjectTeacherDataGridViewTextBoxColumn1";
            this.subjectTeacherDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // pointDataGridViewTextBoxColumn1
            // 
            this.pointDataGridViewTextBoxColumn1.DataPropertyName = "Point";
            this.pointDataGridViewTextBoxColumn1.HeaderText = "نمره :";
            this.pointDataGridViewTextBoxColumn1.Name = "pointDataGridViewTextBoxColumn1";
            this.pointDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // subPresentIDDataGridViewTextBoxColumn1
            // 
            this.subPresentIDDataGridViewTextBoxColumn1.DataPropertyName = "Sub_Present_ID";
            this.subPresentIDDataGridViewTextBoxColumn1.HeaderText = "کد ارائه :";
            this.subPresentIDDataGridViewTextBoxColumn1.Name = "subPresentIDDataGridViewTextBoxColumn1";
            this.subPresentIDDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // teacherPresentIDDataGridViewTextBoxColumn1
            // 
            this.teacherPresentIDDataGridViewTextBoxColumn1.DataPropertyName = "Teacher_Present_ID";
            this.teacherPresentIDDataGridViewTextBoxColumn1.HeaderText = "کد استاد درس :";
            this.teacherPresentIDDataGridViewTextBoxColumn1.Name = "teacherPresentIDDataGridViewTextBoxColumn1";
            this.teacherPresentIDDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // karnameds
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(854, 545);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(488, 297);
            this.Name = "karnameds";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentSubSelectedBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniWebDataSet5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private TableLayoutPanel tableLayoutPanel1;
        private DataGridView dataGridView1;
        private Button button4;
        private UniWebDataSet5 uniWebDataSet5;
        private BindingSource studentSubSelectedBindingSource;
        private UniWebDataSet5TableAdapters.StudentSubSelectedTableAdapter studentSubSelectedTableAdapter;
        private DataGridViewTextBoxColumn studentIdDataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn subjectIdDataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn subjectNameDataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn subjectUnitDataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn subjectTeacherDataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn pointDataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn subPresentIDDataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn teacherPresentIDDataGridViewTextBoxColumn1;
    }
}
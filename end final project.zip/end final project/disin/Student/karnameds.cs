﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace disin.Head
{
    public partial class karnameds : Form
    {
        public SqlConnection sqlcon;
        public SqlDataAdapter adapt;
        public DataTable dt;
        public BindingSource bs;
        Bitmap bmp;

        public karnameds()
        {
            InitializeComponent();
            
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'uniWebDataSet5.StudentSubSelected' table. You can move, or remove it, as needed.
            this.studentSubSelectedTableAdapter.Fill(this.uniWebDataSet5.StudentSubSelected);
            sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
            sqlcon.Open();
            RefreshDatagridview();
        }

        public void RefreshDatagridview()
        {

                adapt = new SqlDataAdapter("select * from StudentSubSelected where Student_Id='"+Class1.CurrentId+"'", sqlcon);
                dt = new DataTable();
                adapt.Fill(dt);
                bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
            if(dt.Rows.Count>0)
                dataGridView1.Visible= true;
            else
                dataGridView1.Visible= false;
        }       
    }
}
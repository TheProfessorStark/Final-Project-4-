﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using WindowsFormsApp2;
using disin;

namespace WindowsFormsApp2
{
    public partial class ProfessorLogin : Form
    {
        public SqlConnection sqlcon;
        public SqlDataReader dr;
        public SqlCommand com;
        public SqlDataAdapter adapt;
        public DataTable dt;

        public ProfessorLogin()
        {
            InitializeComponent();
        }

        private void ProfessorLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Restart();
        }

        private void txtUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtPassword_Click(sender, e);
                    txtPassword.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    btnEnter_Click(sender, e);
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtUsername_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == ": کد پرسنلی")
                txtUsername.Text = null;
        }

        private void txtPassword_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text == ":رمز عبور")
            {
                txtPassword.Text = null;
            }
        }

        private void txtUsername_Leave(object sender, EventArgs e)
        {
            if (txtUsername.Text == "")
            {
                txtUsername.Text = ": کد پرسنلی";
            }
        }

        private void txtPassword_Leave(object sender, EventArgs e)
        {
            if (txtPassword.Text == "")
                txtPassword.Text = ":رمز عبور";
            if (checkBox1.Checked == false && txtPassword.UseSystemPasswordChar == true && txtPassword.Text == ":رمز عبور")
                txtPassword.UseSystemPasswordChar = false;
            else if (checkBox1.Checked == true && txtPassword.Text == ":رمز عبور")
                txtPassword.Text = ":رمز عبور";

        }

        private void txtPassword_TextChanged_1(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
            {
                txtPassword.UseSystemPasswordChar = true;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = false;
            }
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text != "" && txtPassword.Text != "")
            {
                if (txtUsername.Text != ": کد پرسنلی" && txtPassword.Text != ":رمز عبور")
                {
                    sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
                    sqlcon.Open();
                    com = new SqlCommand("select * from MastersInfo where Personal_Id='" + Convert.ToInt32(txtUsername.Text) + "'and Password='" + Convert.ToInt32(txtPassword.Text) + "'", sqlcon);
                    dr = com.ExecuteReader();
                    if (dr.Read())
                    {
                        Class1.CurrentId = Convert.ToInt32(txtUsername.Text);
                        Class1.CurrentName = dr[1].ToString() +" "+ dr[2].ToString();
                        dr.Close();
                        this.Hide();
                        this.Close();
                        new professormain().ShowDialog();
                    }
                    else
                    {
                        DialogResult dr = MessageBox.Show("اطلاعاتت رو مثل ادم وارد کن ...", "خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        if (dr == DialogResult.OK)
                        {
                            txtUsername.Text = ": کد پرسنلی";
                            txtPassword.Text = ":رمز عبور";
                            txtPassword.UseSystemPasswordChar=false;
                        }
                        sqlcon.Close();
                    }
                }
                else
                {
                    MessageBox.Show("خداییش من الان چه کنم؟؟ درست وارد کن اطلاعات رو", "اخطار", MessageBoxButtons.OK);
                }
            }
            else
            {
                MessageBox.Show("خداییش من الان چه کنم؟؟ درست وارد کن اطلاعات رو", "اخطار", MessageBoxButtons.OK);
            }
        }

        private void checkBox1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false && txtPassword.Text != ":رمز عبور")
            {
                txtPassword.UseSystemPasswordChar = true;
            }
            else if (checkBox1.Checked == true && txtPassword.Text != ":رمز عبور")
                txtPassword.UseSystemPasswordChar = false;
        }

        private void btnForgetPassword_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Close();
            new ForgetPassProfessor().ShowDialog();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

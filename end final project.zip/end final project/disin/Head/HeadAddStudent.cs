﻿using DevComponents.Schedule.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{

    public partial class HeadAddStudent : Form
    {
        public SqlConnection sqlcon;
        public SqlDataAdapter adapt;
        public DataTable dt;
        public BindingSource bs;
        public SqlCommand cmd;
        public SqlDataReader dr;
        public bool edit = false;

        public HeadAddStudent()
        {
            InitializeComponent();
        }


        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (panel1.Visible == false)
                panel1.Visible = true;
            else
                panel1.Visible = false;
        }                       

        private void txtName_Click(object sender, EventArgs e)
        {

        }

        private void txtLastName_Click(object sender, EventArgs e)
        {

        }

        private void txtNationalCode_Click(object sender, EventArgs e)
        {

        }

        private void txtFatherName_Click(object sender, EventArgs e)
        {

        }

        private void txtStudentCode_Click(object sender, EventArgs e)
        {

        }

        private void txtBirthDate_Click(object sender, EventArgs e)
        {

        }

        private void txtMajor_Click(object sender, EventArgs e)
        {

        }

        private void txtGrade_Click(object sender, EventArgs e)
        {

        }

        private void txtPhoneNum_Click(object sender, EventArgs e)
        {

        }

        private void txtAddress_Click(object sender, EventArgs e)
        {

        }

        private void txtPassword_Click(object sender, EventArgs e)
        {

        }

        private void txtEnterYear_Click(object sender, EventArgs e)
        {

        }

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtLastName_Click(sender, e);
                    txtLastName.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
            
        }

        private void txtLastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtNationalCode_Click(sender, e);
                    txtNationalCode.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
           
        }

        private void txtNationalCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtFatherName_Click(sender, e);
                    txtFatherName.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
            
        }

        private void txtFatherName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtStudentCode_Click(sender, e);
                    txtStudentCode.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
            
        }

        private void txtStudentCode_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                   
                    numericUpDownyear.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
            
        }

        private void txtBirthDate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtMajor_Click(sender, e);
                    txtMajor.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
            
        }

        private void txtMajor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space )
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    comboBoxEx1_Click(sender, e);
                    comboBoxEx1.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
            
        }

        private void txtGrade_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtPhoneNum_Click(sender, e);
                    txtPhoneNum.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
            
        }

        private void txtPhoneNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtPassword_Click(sender, e);
                    txtPassword.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
            
        }

        private void txtAddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) ||char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back || e.KeyChar == (char)Keys.Space)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    label10_Click(sender, e);
                    
                }
            }
            else
            {
                e.Handled = true;
            }
        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtEnterYear_Click(sender, e);
                    txtEnterYear.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
            
        }

        private void txtEnterYear_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back)
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    txtAddress_Click(sender, e);
                    txtAddress.Select();
                }
            }
            else
            {
                e.Handled = true;
            }
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'uniWebDataSet1.StudentInfo' table. You can move, or remove it, as needed.
            this.studentInfoTableAdapter.Fill(this.uniWebDataSet1.StudentInfo);
            panel1.Visible = false;

            sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
            sqlcon.Open();

            RefreshDatagridview(null);
        }

        public void RefreshDatagridview(string SearchText)
        {
            if (SearchText == null)
            {
                adapt = new SqlDataAdapter("select * from StudentInfo", sqlcon);

                dt = new DataTable();

                adapt.Fill(dt);
                bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
            }
            else
            {
                adapt = new SqlDataAdapter("select * from StudentInfo where ID like'" + SearchText + "%'", sqlcon);
                dt = new DataTable();

                adapt.Fill(dt);
                bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
            }

            if (dt.Rows.Count > 0)
                dataGridView1.Visible = true;
            else
                dataGridView1.Visible = false;
        }

        private void label10_Click(object sender, EventArgs e)
        {
            if (txtName.Text.Trim() != "" && txtLastName.Text.Trim() != "" && txtNationalCode.Text != "" && txtFatherName.Text.Trim() != "" && txtStudentCode.Text != "" &&
                txtMajor.Text.Trim() != "" && comboBoxEx1.Text != "" && txtPhoneNum.Text != "" && txtAddress.Text.Trim() != "" && txtPassword.Text != ""
                && txtEnterYear.Text != "")
            {
                DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
                if (resualt == DialogResult.OK)
                {
                    if (edit == false)
                    {
                        DataRow newrow = dt.NewRow();
                        newrow["ID"] = Convert.ToInt64(txtStudentCode.Text);
                        newrow["First_Name"] = txtName.Text.TrimEnd().TrimStart();
                        newrow["Last_Name"] = txtLastName.Text.TrimEnd().TrimStart();
                        newrow["Father_Name"] = txtFatherName.Text.TrimEnd().TrimStart();
                        newrow["National_Code"] = txtNationalCode.Text;
                        string day, month;
                        if (numericUpDownday.Value < 10)
                            day = '0' + numericUpDownday.Value.ToString();
                        else
                            day = numericUpDownday.Value.ToString();
                        if (numericUpDownmonth.Value < 10)
                            month = '0' + numericUpDownmonth.Value.ToString();
                        else
                            month = numericUpDownmonth.Value.ToString();
                        newrow["Birth_Date"] = numericUpDownyear.Value.ToString() + '/' + month + '/' + day;
                        newrow["Entrance_Date"] = Convert.ToInt64(txtEnterYear.Text);
                        newrow["Major"] = txtMajor.Text.TrimEnd().TrimStart();
                        newrow["Grade"] = comboBoxEx1.Text;
                        newrow["Phone_Number"] = Convert.ToInt64(txtPhoneNum.Text);
                        newrow["Address"] = txtAddress.Text.TrimEnd().TrimStart();
                        newrow["Password"] = Convert.ToInt64(txtPassword.Text);

                        dt.Rows.Add(newrow);

                        SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);
                        adapt.Update(dt);
                        dt.AcceptChanges();
                        cleartxtbox();

                        RefreshDatagridview(null);
                    }
                    else
                    {
                        DataRow newrow = dt.NewRow();
                        newrow["ID"] = Convert.ToInt64(txtStudentCode.Text);
                        newrow["First_Name"] = txtName.Text.TrimEnd().TrimStart();
                        newrow["Last_Name"] = txtLastName.Text.TrimEnd().TrimStart();
                        newrow["Father_Name"] = txtFatherName.Text.TrimEnd().TrimStart();
                        newrow["National_Code"] = txtNationalCode.Text;
                        string day, month;
                        if (numericUpDownday.Value < 10)
                            day = '0' + numericUpDownday.Value.ToString();
                        else
                            day = numericUpDownday.Value.ToString();
                        if (numericUpDownmonth.Value < 10)
                            month = '0' + numericUpDownmonth.Value.ToString();
                        else
                            month = numericUpDownmonth.Value.ToString();
                        newrow["Birth_Date"] = numericUpDownyear.Value.ToString() + '/' + month + '/' + day;
                        newrow["Entrance_Date"] = Convert.ToInt64(txtEnterYear.Text);
                        newrow["Major"] = txtMajor.Text.TrimEnd().TrimStart();
                        newrow["Grade"] = comboBoxEx1.Text;
                        newrow["Phone_Number"] = Convert.ToInt64(txtPhoneNum.Text);
                        newrow["Address"] = txtAddress.Text;
                        newrow["Password"] = Convert.ToInt64(txtPassword.Text);

                        dt.Rows.Add(newrow);

                        DataRow crow = getrow();
                        SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);

                        adapt = sqlb.DataAdapter;
                        crow.Delete();
                        adapt.Update(dt);
                        dt.AcceptChanges();
                        cleartxtbox();

                        edit = false;
                        RefreshDatagridview(null);
                    }
                }
                else if (resualt == DialogResult.Cancel)
                {
                    cleartxtbox();
                }
            }
            else
            {
                MessageBox.Show("خداییش من الان چه کنم؟؟ درست وارد کن اطلاعات رو", "!!خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private DataRow getrow()
        {
            if (bs.Current != null)
            {
                return ((DataRowView)bs.Current).Row;
            }
            else
            {
                return null;
            }
        }
        private void label9_Click(object sender, EventArgs e)
        {
            DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            if (resualt == DialogResult.OK)
            {
                DataRow crow = getrow();
                SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);

                adapt = sqlb.DataAdapter;
                crow.Delete();
                adapt.Update(dt);
                dt.AcceptChanges();
                RefreshDatagridview(null);
                cleartxtbox();
            }
                
        }
		
		private void label8_Click(object sender, EventArgs e)
        {

            if(getrow() != null)
            {
                SqlCommandBuilder sqlb1 = new SqlCommandBuilder(adapt);
                edit = true;

                DataRow crow = getrow();

                txtStudentCode.Text = crow["ID"].ToString();
                txtName.Text = crow["First_Name"].ToString();
                txtLastName.Text = crow["Last_Name"].ToString();
                txtFatherName.Text = crow["Father_Name"].ToString();
                txtNationalCode.Text = crow["National_Code"].ToString();
                string day, month, year;
                if (crow["Birth_Date"].ToString()[4] == '/')
                {
                    year = crow["Birth_Date"].ToString().Substring(0, 4);
                    month = crow["Birth_Date"].ToString().Substring(5, 2);
                    day = crow["Birth_Date"].ToString().Substring(8, 2);

                }
                else
                {
                    day = crow["Birth_Date"].ToString().Substring(0, 2);
                    month = crow["Birth_Date"].ToString().Substring(3, 2);
                    year = crow["Birth_Date"].ToString().Substring(6, 4);

                }
                int Day = Convert.ToInt32(day);
                int Month = Convert.ToInt32(month);
                int Year = Convert.ToInt32(year);
                numericUpDownyear.Value = Year; numericUpDownmonth.Value = Month; numericUpDownday.Value = Day;
                txtEnterYear.Text = crow["Entrance_Date"].ToString();
                txtMajor.Text = crow["Major"].ToString();
                comboBoxEx1.Text = crow["Grade"].ToString();
                txtPhoneNum.Text = crow["Phone_Number"].ToString();
                txtAddress.Text = crow["Address"].ToString();
                txtPassword.Text = crow["Password"].ToString();
            }
            panel1.Visible = true;
        }

        private void txt_search_Click(object sender, EventArgs e)
        {
            if (txt_search.Text == "جستجو : کد دانشجویی")
                txt_search.Text = null;
        }

        private void txt_search_Leave(object sender, EventArgs e)
        {
            if (txt_search.Text == "")
            {
                txt_search.Text = "جستجو : کد دانشجویی";
                RefreshDatagridview(null);
            }
            //event Search_Leave;
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            RefreshDatagridview(txt_search.Text);
        }
        public void cleartxtbox()
        {
            txtStudentCode.Text = null; txtName.Text = null;
            txtLastName.Text = null; txtFatherName.Text = null;
            txtNationalCode.Text = null; numericUpDownyear.Value = 1300; numericUpDownmonth.Value = 1; numericUpDownday.Value = 1;
            txtEnterYear.Text = null; txtMajor.Text = null;
            comboBoxEx1.Text = null; txtPhoneNum.Text = null;
            txtAddress.Text = null; txtPassword.Text = null;
        }

        private void comboBoxEx1_Click(object sender, EventArgs e)
        {

        }
        private void numericUpDownday_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDownmonth.Value < 7)
                numericUpDownday.Maximum = 31;
            else if (numericUpDownmonth.Value == 12)
                numericUpDownday.Maximum = 29;
            else
                numericUpDownday.Maximum = 30;
        }

        private void numericUpDownmonth_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDownmonth.Value > 6 && numericUpDownday.Value > 30)
                numericUpDownday.Value = 30;
            if (numericUpDownmonth.Value > 11 && numericUpDownday.Value > 29)
                numericUpDownday.Value = 29;
            if (numericUpDownmonth.Value < 7 && numericUpDownday.Value == 30)
            {
                numericUpDownday_ValueChanged(sender, e);
                numericUpDownday.Value = 31;
            }
            if (numericUpDownmonth.Value < 12 && numericUpDownday.Value == 29)
            {
                numericUpDownday_ValueChanged(sender, e);
                numericUpDownday.Value = 30;
            }


        }
    }
}

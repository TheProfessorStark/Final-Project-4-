﻿using System.Windows.Forms;

namespace WindowsFormsApp2
{
    partial class addlesonP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addlesonP));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUnitNumber = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtLessonName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtLessonCode = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panels1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label17 = new System.Windows.Forms.Label();
            this.numericUpDownday2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownmonth2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownyear2 = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label15 = new System.Windows.Forms.Label();
            this.numericUpDownday = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownmonth = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownyear = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.comboBoxEx1 = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.comboItem1 = new DevComponents.Editors.ComboItem();
            this.comboItem2 = new DevComponents.Editors.ComboItem();
            this.comboItem3 = new DevComponents.Editors.ComboItem();
            this.comboItem4 = new DevComponents.Editors.ComboItem();
            this.comboItem5 = new DevComponents.Editors.ComboItem();
            this.comboItem6 = new DevComponents.Editors.ComboItem();
            this.txtTeacherId = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtpresentid = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtTeacher = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.button3 = new System.Windows.Forms.Button();
            this.btn_openpanl = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.subjectIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subjectNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subjectUnitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.classStartDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.examDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teacherPresentationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dayPresentationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hourPresentationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.presentIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teacherPresentIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teacherSubSelectedBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.uniWebDataSet3 = new disin.UniWebDataSet3();
            this.teacherSubSelectedTableAdapter = new disin.UniWebDataSet3TableAdapters.TeacherSubSelectedTableAdapter();
            this.panels1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownday2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownmonth2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownyear2)).BeginInit();
            this.panel5.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownday)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownmonth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownyear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_openpanl)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherSubSelectedBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniWebDataSet3)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(178, 123);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 25);
            this.label2.TabIndex = 10;
            this.label2.Text = ":روزها";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(178, 45);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 25);
            this.label1.TabIndex = 10;
            this.label1.Text = ":کد درس";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(176, 163);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 25);
            this.label3.TabIndex = 10;
            this.label3.Text = ":زمان کلاس";
            // 
            // txtUnitNumber
            // 
            this.txtUnitNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtUnitNumber.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtUnitNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUnitNumber.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.txtUnitNumber.ForeColor = System.Drawing.Color.White;
            this.txtUnitNumber.Location = new System.Drawing.Point(7, 243);
            this.txtUnitNumber.MaxLength = 1;
            this.txtUnitNumber.Name = "txtUnitNumber";
            this.txtUnitNumber.Size = new System.Drawing.Size(162, 31);
            this.txtUnitNumber.TabIndex = 5;
            this.txtUnitNumber.Click += new System.EventHandler(this.txtUnitNumber_Click);
            this.txtUnitNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUnitNumber_KeyPress);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(178, 205);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 25);
            this.label4.TabIndex = 10;
            this.label4.Text = ": اسم درس";
            // 
            // txtLessonName
            // 
            this.txtLessonName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtLessonName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtLessonName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLessonName.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.txtLessonName.ForeColor = System.Drawing.Color.White;
            this.txtLessonName.Location = new System.Drawing.Point(7, 202);
            this.txtLessonName.Name = "txtLessonName";
            this.txtLessonName.Size = new System.Drawing.Size(162, 31);
            this.txtLessonName.TabIndex = 4;
            this.txtLessonName.Click += new System.EventHandler(this.txtLessonName_Click);
            this.txtLessonName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLessonName_KeyPress);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(178, 245);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 25);
            this.label5.TabIndex = 10;
            this.label5.Text = ": تعداد واحد ها";
            // 
            // txtLessonCode
            // 
            this.txtLessonCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtLessonCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtLessonCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLessonCode.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.txtLessonCode.ForeColor = System.Drawing.Color.White;
            this.txtLessonCode.Location = new System.Drawing.Point(7, 42);
            this.txtLessonCode.Name = "txtLessonCode";
            this.txtLessonCode.Size = new System.Drawing.Size(162, 31);
            this.txtLessonCode.TabIndex = 1;
            this.txtLessonCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLessonCode_KeyPress);
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(176, 288);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 25);
            this.label6.TabIndex = 10;
            this.label6.Text = ":شروع کلاس ها";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(178, 329);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 25);
            this.label7.TabIndex = 10;
            this.label7.Text = ":بایانترم";
            // 
            // panels1
            // 
            this.panels1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.panels1.Controls.Add(this.panel6);
            this.panels1.Controls.Add(this.panel5);
            this.panels1.Controls.Add(this.label14);
            this.panels1.Controls.Add(this.numericUpDown2);
            this.panels1.Controls.Add(this.numericUpDown1);
            this.panels1.Controls.Add(this.comboBoxEx1);
            this.panels1.Controls.Add(this.txtTeacherId);
            this.panels1.Controls.Add(this.label13);
            this.panels1.Controls.Add(this.txtpresentid);
            this.panels1.Controls.Add(this.label12);
            this.panels1.Controls.Add(this.label11);
            this.panels1.Controls.Add(this.txtTeacher);
            this.panels1.Controls.Add(this.panel3);
            this.panels1.Controls.Add(this.panel2);
            this.panels1.Controls.Add(this.panel1);
            this.panels1.Controls.Add(this.label7);
            this.panels1.Controls.Add(this.label6);
            this.panels1.Controls.Add(this.txtLessonCode);
            this.panels1.Controls.Add(this.label5);
            this.panels1.Controls.Add(this.txtLessonName);
            this.panels1.Controls.Add(this.label4);
            this.panels1.Controls.Add(this.txtUnitNumber);
            this.panels1.Controls.Add(this.label3);
            this.panels1.Controls.Add(this.label1);
            this.panels1.Controls.Add(this.label2);
            this.panels1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panels1.Location = new System.Drawing.Point(630, 0);
            this.panels1.Margin = new System.Windows.Forms.Padding(2);
            this.panels1.Name = "panels1";
            this.panels1.Size = new System.Drawing.Size(306, 539);
            this.panels1.TabIndex = 11;
            // 
            // panel6
            // 
            this.panel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.tableLayoutPanel4);
            this.panel6.Location = new System.Drawing.Point(7, 329);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(162, 31);
            this.panel6.TabIndex = 68;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 5;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.99999F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.00001F));
            this.tableLayoutPanel4.Controls.Add(this.label17, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.numericUpDownday2, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.numericUpDownmonth2, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.numericUpDownyear2, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label18, 3, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(158, 27);
            this.tableLayoutPanel4.TabIndex = 52;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = System.Windows.Forms.DockStyle.Top;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(53, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(12, 17);
            this.label17.TabIndex = 4;
            this.label17.Text = "/";
            this.label17.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // numericUpDownday2
            // 
            this.numericUpDownday2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.numericUpDownday2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDownday2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDownday2.ForeColor = System.Drawing.Color.White;
            this.numericUpDownday2.Location = new System.Drawing.Point(124, 3);
            this.numericUpDownday2.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
            this.numericUpDownday2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownday2.Name = "numericUpDownday2";
            this.numericUpDownday2.Size = new System.Drawing.Size(31, 16);
            this.numericUpDownday2.TabIndex = 2;
            this.numericUpDownday2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownday2.ValueChanged += new System.EventHandler(this.numericUpDownday2_ValueChanged);
            // 
            // numericUpDownmonth2
            // 
            this.numericUpDownmonth2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.numericUpDownmonth2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDownmonth2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDownmonth2.ForeColor = System.Drawing.Color.White;
            this.numericUpDownmonth2.Location = new System.Drawing.Point(71, 3);
            this.numericUpDownmonth2.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.numericUpDownmonth2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownmonth2.Name = "numericUpDownmonth2";
            this.numericUpDownmonth2.Size = new System.Drawing.Size(29, 16);
            this.numericUpDownmonth2.TabIndex = 1;
            this.numericUpDownmonth2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownmonth2.ValueChanged += new System.EventHandler(this.numericUpDownmonth2_ValueChanged);
            // 
            // numericUpDownyear2
            // 
            this.numericUpDownyear2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.numericUpDownyear2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDownyear2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDownyear2.ForeColor = System.Drawing.Color.White;
            this.numericUpDownyear2.Location = new System.Drawing.Point(3, 3);
            this.numericUpDownyear2.Maximum = new decimal(new int[] {
            1407,
            0,
            0,
            0});
            this.numericUpDownyear2.Minimum = new decimal(new int[] {
            1300,
            0,
            0,
            0});
            this.numericUpDownyear2.Name = "numericUpDownyear2";
            this.numericUpDownyear2.Size = new System.Drawing.Size(44, 16);
            this.numericUpDownyear2.TabIndex = 0;
            this.numericUpDownyear2.Value = new decimal(new int[] {
            1300,
            0,
            0,
            0});
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Top;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(106, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(12, 17);
            this.label18.TabIndex = 3;
            this.label18.Text = "/";
            this.label18.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // panel5
            // 
            this.panel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.tableLayoutPanel7);
            this.panel5.Location = new System.Drawing.Point(7, 287);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(162, 31);
            this.panel5.TabIndex = 67;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 5;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.99999F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.00001F));
            this.tableLayoutPanel7.Controls.Add(this.label15, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.numericUpDownday, 4, 0);
            this.tableLayoutPanel7.Controls.Add(this.numericUpDownmonth, 2, 0);
            this.tableLayoutPanel7.Controls.Add(this.numericUpDownyear, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.label16, 3, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(158, 27);
            this.tableLayoutPanel7.TabIndex = 52;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Top;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(53, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(12, 17);
            this.label15.TabIndex = 4;
            this.label15.Text = "/";
            this.label15.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // numericUpDownday
            // 
            this.numericUpDownday.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.numericUpDownday.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDownday.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDownday.ForeColor = System.Drawing.Color.White;
            this.numericUpDownday.Location = new System.Drawing.Point(124, 3);
            this.numericUpDownday.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
            this.numericUpDownday.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownday.Name = "numericUpDownday";
            this.numericUpDownday.Size = new System.Drawing.Size(31, 16);
            this.numericUpDownday.TabIndex = 2;
            this.numericUpDownday.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownday.ValueChanged += new System.EventHandler(this.numericUpDownday_ValueChanged);
            // 
            // numericUpDownmonth
            // 
            this.numericUpDownmonth.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.numericUpDownmonth.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDownmonth.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDownmonth.ForeColor = System.Drawing.Color.White;
            this.numericUpDownmonth.Location = new System.Drawing.Point(71, 3);
            this.numericUpDownmonth.Maximum = new decimal(new int[] {
            12,
            0,
            0,
            0});
            this.numericUpDownmonth.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownmonth.Name = "numericUpDownmonth";
            this.numericUpDownmonth.Size = new System.Drawing.Size(29, 16);
            this.numericUpDownmonth.TabIndex = 1;
            this.numericUpDownmonth.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownmonth.ValueChanged += new System.EventHandler(this.numericUpDownmonth_ValueChanged);
            // 
            // numericUpDownyear
            // 
            this.numericUpDownyear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.numericUpDownyear.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.numericUpDownyear.Dock = System.Windows.Forms.DockStyle.Fill;
            this.numericUpDownyear.ForeColor = System.Drawing.Color.White;
            this.numericUpDownyear.Location = new System.Drawing.Point(3, 3);
            this.numericUpDownyear.Maximum = new decimal(new int[] {
            1407,
            0,
            0,
            0});
            this.numericUpDownyear.Minimum = new decimal(new int[] {
            1300,
            0,
            0,
            0});
            this.numericUpDownyear.Name = "numericUpDownyear";
            this.numericUpDownyear.Size = new System.Drawing.Size(44, 16);
            this.numericUpDownyear.TabIndex = 0;
            this.numericUpDownyear.Value = new decimal(new int[] {
            1300,
            0,
            0,
            0});
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Top;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(106, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(12, 17);
            this.label16.TabIndex = 3;
            this.label16.Text = "/";
            this.label16.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(80, 164);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(16, 24);
            this.label14.TabIndex = 66;
            this.label14.Text = ":";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.numericUpDown2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.numericUpDown2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown2.ForeColor = System.Drawing.Color.White;
            this.numericUpDown2.Location = new System.Drawing.Point(107, 163);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            59,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(61, 26);
            this.numericUpDown2.TabIndex = 65;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.numericUpDown1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown1.ForeColor = System.Drawing.Color.White;
            this.numericUpDown1.Location = new System.Drawing.Point(7, 164);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(62, 26);
            this.numericUpDown1.TabIndex = 64;
            // 
            // comboBoxEx1
            // 
            this.comboBoxEx1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxEx1.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(15)))), ((int)(((byte)(40)))));
            this.comboBoxEx1.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(15)))), ((int)(((byte)(40)))));
            this.comboBoxEx1.DisplayMember = "Text";
            this.comboBoxEx1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxEx1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEx1.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.comboBoxEx1.FocusHighlightColor = System.Drawing.Color.Gainsboro;
            this.comboBoxEx1.FormattingEnabled = true;
            this.comboBoxEx1.ItemHeight = 17;
            this.comboBoxEx1.Items.AddRange(new object[] {
            this.comboItem1,
            this.comboItem2,
            this.comboItem3,
            this.comboItem4,
            this.comboItem5,
            this.comboItem6});
            this.comboBoxEx1.Location = new System.Drawing.Point(7, 126);
            this.comboBoxEx1.Name = "comboBoxEx1";
            this.comboBoxEx1.Size = new System.Drawing.Size(160, 23);
            this.comboBoxEx1.Style = DevComponents.DotNetBar.eDotNetBarStyle.Windows7;
            this.comboBoxEx1.TabIndex = 61;
            this.comboBoxEx1.WatermarkText = "انتخاب کنید...";
            this.comboBoxEx1.Click += new System.EventHandler(this.comboBoxEx1_Click);
            // 
            // comboItem1
            // 
            this.comboItem1.Text = "شنبه";
            // 
            // comboItem2
            // 
            this.comboItem2.Text = "یکشنبه";
            // 
            // comboItem3
            // 
            this.comboItem3.Text = "دوشنبه";
            // 
            // comboItem4
            // 
            this.comboItem4.Text = "سه شنبه";
            // 
            // comboItem5
            // 
            this.comboItem5.Text = "چهارشنبه";
            // 
            // comboItem6
            // 
            this.comboItem6.Text = "پنجشنبه";
            // 
            // txtTeacherId
            // 
            this.txtTeacherId.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTeacherId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtTeacherId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTeacherId.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.txtTeacherId.ForeColor = System.Drawing.Color.White;
            this.txtTeacherId.Location = new System.Drawing.Point(9, 414);
            this.txtTeacherId.Name = "txtTeacherId";
            this.txtTeacherId.Size = new System.Drawing.Size(162, 31);
            this.txtTeacherId.TabIndex = 17;
            this.txtTeacherId.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTeacherId_KeyPress);
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label13.Location = new System.Drawing.Point(179, 419);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(124, 17);
            this.label13.TabIndex = 18;
            this.label13.Text = ": کد استاد ارائه دهنده";
            // 
            // txtpresentid
            // 
            this.txtpresentid.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtpresentid.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtpresentid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtpresentid.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.txtpresentid.ForeColor = System.Drawing.Color.White;
            this.txtpresentid.Location = new System.Drawing.Point(7, 81);
            this.txtpresentid.Name = "txtpresentid";
            this.txtpresentid.Size = new System.Drawing.Size(162, 31);
            this.txtpresentid.TabIndex = 15;
            this.txtpresentid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpresentid_KeyPress);
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(178, 84);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 25);
            this.label12.TabIndex = 16;
            this.label12.Text = ":کد ارائه درس";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(178, 376);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(123, 20);
            this.label11.TabIndex = 14;
            this.label11.Text = ": استاد ارائه دهنده";
            // 
            // txtTeacher
            // 
            this.txtTeacher.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtTeacher.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtTeacher.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTeacher.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.txtTeacher.ForeColor = System.Drawing.Color.White;
            this.txtTeacher.Location = new System.Drawing.Point(7, 372);
            this.txtTeacher.Name = "txtTeacher";
            this.txtTeacher.Size = new System.Drawing.Size(162, 31);
            this.txtTeacher.TabIndex = 8;
            this.txtTeacher.Click += new System.EventHandler(this.txtTeacher_Click);
            this.txtTeacher.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTeacher_KeyPress);
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Location = new System.Drawing.Point(13, 458);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(90, 37);
            this.panel3.TabIndex = 12;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(3, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(33, 28);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 30);
            this.label10.TabIndex = 11;
            this.label10.Text = "ثبت";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label10.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(109, 458);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(90, 37);
            this.panel2.TabIndex = 12;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(33, 28);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 30);
            this.label9.TabIndex = 10;
            this.label9.Text = "حذف";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label9.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Location = new System.Drawing.Point(205, 458);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(90, 37);
            this.panel1.TabIndex = 11;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::disin.Properties.Resources.edit_512px;
            this.pictureBox1.Location = new System.Drawing.Point(3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 28);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 30);
            this.label8.TabIndex = 9;
            this.label8.Text = "ویرایش";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label8.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Controls.Add(this.txtSearch, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 502);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(624, 34);
            this.tableLayoutPanel3.TabIndex = 3;
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.txtSearch.ForeColor = System.Drawing.Color.White;
            this.txtSearch.Location = new System.Drawing.Point(3, 3);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(618, 31);
            this.txtSearch.TabIndex = 0;
            this.txtSearch.Text = "جستجو : کد درس";
            this.txtSearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtSearch.Click += new System.EventHandler(this.txtSearch_Click);
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            this.txtSearch.Leave += new System.EventHandler(this.txtSearch_Leave);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel2.Controls.Add(this.button3, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.btn_openpanl, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(624, 34);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // button3
            // 
            this.button3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.Location = new System.Drawing.Point(2, 2);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(586, 30);
            this.button3.TabIndex = 17;
            this.button3.Text = "تغییر دروس ارایه شده";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // btn_openpanl
            // 
            this.btn_openpanl.Dock = System.Windows.Forms.DockStyle.Right;
            this.btn_openpanl.Image = global::disin.Properties.Resources.menu_vertical_96px;
            this.btn_openpanl.Location = new System.Drawing.Point(593, 3);
            this.btn_openpanl.Name = "btn_openpanl";
            this.btn_openpanl.Size = new System.Drawing.Size(28, 28);
            this.btn_openpanl.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_openpanl.TabIndex = 15;
            this.btn_openpanl.TabStop = false;
            this.btn_openpanl.Click += new System.EventHandler(this.btn_openpanl_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(630, 539);
            this.tableLayoutPanel1.TabIndex = 11;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.dataGridView1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 43);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(624, 453);
            this.panel4.TabIndex = 4;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.DarkCyan;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            this.dataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.DarkCyan;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeight = 25;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.subjectIDDataGridViewTextBoxColumn,
            this.subjectNameDataGridViewTextBoxColumn,
            this.subjectUnitDataGridViewTextBoxColumn,
            this.classStartDateDataGridViewTextBoxColumn,
            this.examDateDataGridViewTextBoxColumn,
            this.teacherPresentationDataGridViewTextBoxColumn,
            this.dayPresentationDataGridViewTextBoxColumn,
            this.hourPresentationDataGridViewTextBoxColumn,
            this.presentIDDataGridViewTextBoxColumn,
            this.teacherPresentIDDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.teacherSubSelectedBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.DarkCyan;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.GridColor = System.Drawing.Color.DimGray;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(10);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.DarkCyan;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(45)))));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.DarkCyan;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.ShowCellErrors = false;
            this.dataGridView1.ShowCellToolTips = false;
            this.dataGridView1.ShowEditingIcon = false;
            this.dataGridView1.ShowRowErrors = false;
            this.dataGridView1.Size = new System.Drawing.Size(624, 453);
            this.dataGridView1.TabIndex = 12;
            // 
            // subjectIDDataGridViewTextBoxColumn
            // 
            this.subjectIDDataGridViewTextBoxColumn.DataPropertyName = "Subject_ID";
            this.subjectIDDataGridViewTextBoxColumn.HeaderText = "کد درس :";
            this.subjectIDDataGridViewTextBoxColumn.Name = "subjectIDDataGridViewTextBoxColumn";
            this.subjectIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // subjectNameDataGridViewTextBoxColumn
            // 
            this.subjectNameDataGridViewTextBoxColumn.DataPropertyName = "Subject_Name";
            this.subjectNameDataGridViewTextBoxColumn.HeaderText = "اسم درس :";
            this.subjectNameDataGridViewTextBoxColumn.Name = "subjectNameDataGridViewTextBoxColumn";
            this.subjectNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // subjectUnitDataGridViewTextBoxColumn
            // 
            this.subjectUnitDataGridViewTextBoxColumn.DataPropertyName = "Subject_Unit";
            this.subjectUnitDataGridViewTextBoxColumn.HeaderText = "تعداد واحد :";
            this.subjectUnitDataGridViewTextBoxColumn.Name = "subjectUnitDataGridViewTextBoxColumn";
            this.subjectUnitDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // classStartDateDataGridViewTextBoxColumn
            // 
            this.classStartDateDataGridViewTextBoxColumn.DataPropertyName = "ClassStart_Date";
            this.classStartDateDataGridViewTextBoxColumn.HeaderText = "تاریخ شروع کلاس :";
            this.classStartDateDataGridViewTextBoxColumn.Name = "classStartDateDataGridViewTextBoxColumn";
            this.classStartDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // examDateDataGridViewTextBoxColumn
            // 
            this.examDateDataGridViewTextBoxColumn.DataPropertyName = "Exam_Date";
            this.examDateDataGridViewTextBoxColumn.HeaderText = "تاریخ امتحان پایانی :";
            this.examDateDataGridViewTextBoxColumn.Name = "examDateDataGridViewTextBoxColumn";
            this.examDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // teacherPresentationDataGridViewTextBoxColumn
            // 
            this.teacherPresentationDataGridViewTextBoxColumn.DataPropertyName = "Teacher_Presentation";
            this.teacherPresentationDataGridViewTextBoxColumn.HeaderText = "استاد ارائه دهنده :";
            this.teacherPresentationDataGridViewTextBoxColumn.Name = "teacherPresentationDataGridViewTextBoxColumn";
            this.teacherPresentationDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dayPresentationDataGridViewTextBoxColumn
            // 
            this.dayPresentationDataGridViewTextBoxColumn.DataPropertyName = "Day_Presentation";
            this.dayPresentationDataGridViewTextBoxColumn.HeaderText = "روز ارائه :";
            this.dayPresentationDataGridViewTextBoxColumn.Name = "dayPresentationDataGridViewTextBoxColumn";
            this.dayPresentationDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // hourPresentationDataGridViewTextBoxColumn
            // 
            this.hourPresentationDataGridViewTextBoxColumn.DataPropertyName = "Hour_Presentation";
            this.hourPresentationDataGridViewTextBoxColumn.HeaderText = "ساعت ارائه :";
            this.hourPresentationDataGridViewTextBoxColumn.Name = "hourPresentationDataGridViewTextBoxColumn";
            this.hourPresentationDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // presentIDDataGridViewTextBoxColumn
            // 
            this.presentIDDataGridViewTextBoxColumn.DataPropertyName = "Present_ID";
            this.presentIDDataGridViewTextBoxColumn.HeaderText = "کد ارائه درس :";
            this.presentIDDataGridViewTextBoxColumn.Name = "presentIDDataGridViewTextBoxColumn";
            this.presentIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // teacherPresentIDDataGridViewTextBoxColumn
            // 
            this.teacherPresentIDDataGridViewTextBoxColumn.DataPropertyName = "Teacher_Present_ID";
            this.teacherPresentIDDataGridViewTextBoxColumn.HeaderText = "کد استاد ارائه دهنده :";
            this.teacherPresentIDDataGridViewTextBoxColumn.Name = "teacherPresentIDDataGridViewTextBoxColumn";
            this.teacherPresentIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // teacherSubSelectedBindingSource
            // 
            this.teacherSubSelectedBindingSource.DataMember = "TeacherSubSelected";
            this.teacherSubSelectedBindingSource.DataSource = this.uniWebDataSet3;
            // 
            // uniWebDataSet3
            // 
            this.uniWebDataSet3.DataSetName = "UniWebDataSet3";
            this.uniWebDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // teacherSubSelectedTableAdapter
            // 
            this.teacherSubSelectedTableAdapter.ClearBeforeFill = true;
            // 
            // addlesonP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(936, 539);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.panels1);
            this.Name = "addlesonP";
            this.Text = "افزودن درس";
            this.Load += new System.EventHandler(this.addlesonP_Load);
            this.panels1.ResumeLayout(false);
            this.panels1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownday2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownmonth2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownyear2)).EndInit();
            this.panel5.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownday)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownmonth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownyear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btn_openpanl)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherSubSelectedBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uniWebDataSet3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Label label2;
        private Label label1;
        private Label label3;
        private TextBox txtUnitNumber;
        private Label label4;
        private TextBox txtLessonName;
        private Label label5;
        private TextBox txtLessonCode;
        private Label label6;
        private Label label7;
        private Panel panels1;
        private TableLayoutPanel tableLayoutPanel3;
        private TextBox txtSearch;
        private TableLayoutPanel tableLayoutPanel2;
        private Button button3;
        private PictureBox btn_openpanl;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel panel1;
        private PictureBox pictureBox1;
        private Label label8;
        private Panel panel3;
        private PictureBox pictureBox3;
        private Label label10;
        private Panel panel2;
        private PictureBox pictureBox2;
        private Label label9;
        private Label label11;
        private TextBox txtTeacher;
        private Panel panel4;
        private DataGridView dataGridView1;
        private disin.UniWebDataSet3 uniWebDataSet3;
        private BindingSource teacherSubSelectedBindingSource;
        private disin.UniWebDataSet3TableAdapters.TeacherSubSelectedTableAdapter teacherSubSelectedTableAdapter;
        private TextBox txtTeacherId;
        private Label label13;
        private TextBox txtpresentid;
        private Label label12;
        private DataGridViewTextBoxColumn subjectIDDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn subjectNameDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn subjectUnitDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn classStartDateDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn examDateDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn teacherPresentationDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn dayPresentationDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn hourPresentationDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn presentIDDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn teacherPresentIDDataGridViewTextBoxColumn;
        private DevComponents.DotNetBar.Controls.ComboBoxEx comboBoxEx1;
        private DevComponents.Editors.ComboItem comboItem1;
        private DevComponents.Editors.ComboItem comboItem2;
        private DevComponents.Editors.ComboItem comboItem3;
        private DevComponents.Editors.ComboItem comboItem4;
        private DevComponents.Editors.ComboItem comboItem5;
        private DevComponents.Editors.ComboItem comboItem6;
        private Label label14;
        private NumericUpDown numericUpDown2;
        private NumericUpDown numericUpDown1;
        private Panel panel5;
        private TableLayoutPanel tableLayoutPanel7;
        private Label label15;
        private NumericUpDown numericUpDownday;
        private NumericUpDown numericUpDownmonth;
        private NumericUpDown numericUpDownyear;
        private Label label16;
        private Panel panel6;
        private TableLayoutPanel tableLayoutPanel4;
        private Label label17;
        private NumericUpDown numericUpDownday2;
        private NumericUpDown numericUpDownmonth2;
        private NumericUpDown numericUpDownyear2;
        private Label label18;
    }
}
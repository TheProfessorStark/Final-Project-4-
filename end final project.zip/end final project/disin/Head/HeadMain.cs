using disin;
using disin.Head;
using System;
using System.Drawing;
using System.Windows.Forms;
using WindowsFormsApp2;

namespace WindowsFormsApp2
{
    public partial class mainhead : Form
    {
        public Button currentcolor;
        public mainhead()
        {
            InitializeComponent();
            customizeDesing();
        }
        private void customizeDesing()
        {
            paneld1.Visible = false;
            paneld2.Visible = false;
            paneld4.Visible = false;
        }
        private void hideSubMenu()
        {
            if (paneld1.Visible == true)
                paneld1.Visible = false;
            if (paneld2.Visible == true)
                paneld2.Visible = false;
            if (paneld4.Visible == true)
                paneld4.Visible = false;

        }
        private void showSubMenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hideSubMenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;

        }
        //...btn_code


        private Form activeform = null;
        private void openchildform(Form childform)
        {
            if (activeform != null)
                activeform.Close();      
            activeform = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            panelcontainer.Controls.Add(childform);
            panelcontainer.Tag = childform;
            childform.BringToFront();
            childform.Show();
            childform.Size = new Size(1088, 641);
          //  panel1.Visible = false;
            pictureBox2.BringToFront();

        }
        public Button  currentbuttoncolor(Button currentbutton)
        {
            if (currentcolor != null)
                currentcolor.BackColor = Color.FromArgb(15, 32, 39);
            currentcolor = currentbutton;
            currentcolor.BackColor = Color.DarkCyan;
            return null;
        }

        private void btn_addsub_Click(object sender, EventArgs e)
        {
            openchildform(new addlesson());
            currentbuttoncolor((Button)sender);
        }


        private void btnd_editsub_Click(object sender, EventArgs e)
        {
            showSubMenu(paneld1);
        }

        private void btn_editpsub_Click(object sender, EventArgs e)
        {
            openchildform(new addlesonP());
            currentbuttoncolor((Button)sender);
        }

        private void btn_editSsub_Click(object sender, EventArgs e)
        {
            openchildform(new Headstudentlesson());
            currentbuttoncolor((Button)sender);
        }

        private void btn_editstudent_Click(object sender, EventArgs e)
        {
            showSubMenu(paneld2);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            openchildform(new HeadAddStudent());
            currentbuttoncolor((Button)sender);
        }

        private void btn_editp_Click(object sender, EventArgs e)
        {
            showSubMenu(paneld4);
        }

        private void btnkarname_Click(object sender, EventArgs e)
        {
            openchildform(new karnameda());
            currentbuttoncolor((Button)sender);
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            if (panel1.Visible == true)
                panel1.Visible = false;
            else
                panel1.Visible = true;
        }

        private void btnd4_Click(object sender, EventArgs e)
        {
            openchildform(new HeadAddProfessor());
            currentbuttoncolor((Button)sender);
        }

        private void panelcontainer_Paint(object sender, PaintEventArgs e)
        {


        }

        private void mainhead_Load(object sender, EventArgs e)
        {

        }

        private void mainhead_FormClosed(object sender, FormClosedEventArgs e)
        {
        
        }
    }
}
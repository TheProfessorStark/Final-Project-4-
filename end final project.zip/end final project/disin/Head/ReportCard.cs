﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace disin.Head
{
    public partial class karnameda : Form
    {
        public SqlConnection sqlcon;
        public SqlDataAdapter adapt;
        public DataTable dt;
        public BindingSource bs;
        public SqlCommand cmd;
        public SqlDataReader dr;


        public karnameda()
        {
            InitializeComponent();
            customizeDesing();
        }
        private void customizeDesing()
        {
            panelB1.Visible = false;

        }
        private void hideSubMenu()
        {
            if (panelB1.Visible == true)
                panelB1.Visible = false;

        }
        private void showSubMenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hideSubMenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;

        }
        private void label1_Click(object sender, EventArgs e)
        {
            showSubMenu(panelB1);
        }
        private void karnameda_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'uniWebDataSet6.StudentSubSelected' table. You can move, or remove it, as needed.
            this.studentSubSelectedTableAdapter.Fill(this.uniWebDataSet6.StudentSubSelected);
            sqlcon = new SqlConnection("Data Source=.;Initial Catalog=UniWeb;Integrated Security=True");
            sqlcon.Open();

            if (txtSearch.Text == "جستجو : کد دانشجویی" || txtSearch.Text == "")
                RefreshDatagridview(null);
            else
                RefreshDatagridview(txtSearch.Text);
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Back || e.KeyChar=='.')
            {
                e.Handled = false;
                if (e.KeyChar == (char)Keys.Enter)
                {
                    pictureBox3_Click(sender, e);
                }
            }
            else
            {
                e.Handled = true;
            }
        }
        public void RefreshDatagridview(string SearchText)
        {
            if (txtSearch.Text == "جستجو : کد دانشجویی" || txtSearch.Text == "")
            {
                adapt = new SqlDataAdapter("select * from StudentSubSelected ", sqlcon);
                dt = new DataTable();
                adapt.Fill(dt);
                bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
            }
            else

            {
                adapt = new SqlDataAdapter("select * from StudentSubSelected where Student_Id='" + txtSearch.Text + "'", sqlcon);
                dt = new DataTable();
                adapt.Fill(dt);
                bs = new BindingSource();
                bs.DataSource = dt;
                dataGridView1.DataSource = bs;
            }

            if (dt.Rows.Count > 0)
                dataGridView1.Visible = true;
            else
                dataGridView1.Visible = false;
            dataGridView1_Click(this, null);
        }
        private DataRow getrow()
        {
            if (bs.Current != null)
            {
                return ((DataRowView)bs.Current).Row;
            }
            else
            {
                return null;
            }
        }
        private void txtSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text == "جستجو : کد دانشجویی")
                txtSearch.Text = null;
        }

        private void txtSearch_Leave(object sender, EventArgs e)
        {
            if (txtSearch.Text == "")
            {
                txtSearch.Text = "جستجو : کد دانشجویی";
                RefreshDatagridview(null);
            }
            //event Search_Leave;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            RefreshDatagridview(txtSearch.Text);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            DialogResult resualt = MessageBox.Show("ایا از تغییرات مطمعن هستید؟؟", "!! اخطار", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            if (resualt == DialogResult.OK)
            {
                DataRow crow = getrow();
                DataRow newrow = dt.NewRow();
                newrow["Student_Id"] = crow["Student_Id"].ToString();
                newrow["Subject_Id"] = crow["Subject_Id"].ToString();
                newrow["Subject_Name"] = crow["Subject_Name"].ToString();
                newrow["subject_Unit"] = crow["subject_Unit"].ToString();
                newrow["Subject_Teacher"] = crow["Subject_Teacher"].ToString();
                newrow["Sub_Present_ID"] = crow["Sub_Present_ID"].ToString();
                newrow["Teacher_Present_ID"] = crow["Teacher_Present_ID"].ToString();
                newrow["Point"] = textBox1.Text.ToString();


                dt.Rows.Add(newrow);

                SqlCommandBuilder sqlb = new SqlCommandBuilder(adapt);

                adapt = sqlb.DataAdapter;
                crow.Delete();
                adapt.Update(dt);
                dt.AcceptChanges();
                textBox1.Text = null;
                if (txtSearch.Text == "جستجو : کد دانشجویی" || txtSearch.Text == "")
                    RefreshDatagridview(null);
                else
                    RefreshDatagridview(txtSearch.Text);
            }
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            DataRow crow = getrow();
            if (getrow() != null)
                textBox1.Text = crow["Point"].ToString();
            else
                textBox1.Text = null;
        }
    }
}


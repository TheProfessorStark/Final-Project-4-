﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UNI_TEST
{
    public partial class Forget_Pass_Head : Form
    {
        public Forget_Pass_Head()
        {
            InitializeComponent();
        }

        private void txtNationalCode_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

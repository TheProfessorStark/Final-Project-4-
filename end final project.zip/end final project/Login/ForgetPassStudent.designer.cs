﻿namespace UNI_TEST
{
    partial class Forget_Pass_Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCodeSt = new System.Windows.Forms.TextBox();
            this.lblRecoveryPassSt = new System.Windows.Forms.Label();
            this.btnRecord = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtCodeSt
            // 
            this.txtCodeSt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodeSt.Location = new System.Drawing.Point(257, 242);
            this.txtCodeSt.Name = "txtCodeSt";
            this.txtCodeSt.Size = new System.Drawing.Size(269, 29);
            this.txtCodeSt.TabIndex = 15;
            this.txtCodeSt.Text = "کد ملی:";
            // 
            // lblRecoveryPassSt
            // 
            this.lblRecoveryPassSt.AutoSize = true;
            this.lblRecoveryPassSt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecoveryPassSt.Location = new System.Drawing.Point(105, 242);
            this.lblRecoveryPassSt.Name = "lblRecoveryPassSt";
            this.lblRecoveryPassSt.Size = new System.Drawing.Size(79, 24);
            this.lblRecoveryPassSt.TabIndex = 14;
            this.lblRecoveryPassSt.Text = "پسورد شما:";
            // 
            // btnRecord
            // 
            this.btnRecord.Location = new System.Drawing.Point(220, 383);
            this.btnRecord.Name = "btnRecord";
            this.btnRecord.Size = new System.Drawing.Size(110, 33);
            this.btnRecord.TabIndex = 13;
            this.btnRecord.Text = "ثبت";
            this.btnRecord.UseVisualStyleBackColor = true;
            // 
            // Forget_Pass_Student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(598, 543);
            this.Controls.Add(this.txtCodeSt);
            this.Controls.Add(this.lblRecoveryPassSt);
            this.Controls.Add(this.btnRecord);
            this.Name = "Forget_Pass_Student";
            this.Text = "رمز عبور را فراموش کرده اید؟";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCodeSt;
        private System.Windows.Forms.Label lblRecoveryPassSt;
        private System.Windows.Forms.Button btnRecord;
    }
}
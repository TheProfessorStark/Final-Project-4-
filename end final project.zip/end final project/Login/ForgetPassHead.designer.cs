﻿namespace UNI_TEST
{
    partial class Forget_Pass_Head
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRecord = new System.Windows.Forms.Button();
            this.lblRecoveryPassHead = new System.Windows.Forms.Label();
            this.txtCodeHead = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnRecord
            // 
            this.btnRecord.Location = new System.Drawing.Point(225, 394);
            this.btnRecord.Name = "btnRecord";
            this.btnRecord.Size = new System.Drawing.Size(110, 33);
            this.btnRecord.TabIndex = 7;
            this.btnRecord.Text = "ثبت";
            this.btnRecord.UseVisualStyleBackColor = true;
            // 
            // lblRecoveryPassHead
            // 
            this.lblRecoveryPassHead.AutoSize = true;
            this.lblRecoveryPassHead.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecoveryPassHead.Location = new System.Drawing.Point(110, 253);
            this.lblRecoveryPassHead.Name = "lblRecoveryPassHead";
            this.lblRecoveryPassHead.Size = new System.Drawing.Size(79, 24);
            this.lblRecoveryPassHead.TabIndex = 8;
            this.lblRecoveryPassHead.Text = "پسورد شما:";
            // 
            // txtCodeHead
            // 
            this.txtCodeHead.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCodeHead.Location = new System.Drawing.Point(262, 253);
            this.txtCodeHead.Name = "txtCodeHead";
            this.txtCodeHead.Size = new System.Drawing.Size(269, 29);
            this.txtCodeHead.TabIndex = 9;
            this.txtCodeHead.Text = "کد ملی:";
            this.txtCodeHead.TextChanged += new System.EventHandler(this.txtNationalCode_TextChanged);
            // 
            // Forget_Pass_Head
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(598, 543);
            this.Controls.Add(this.txtCodeHead);
            this.Controls.Add(this.lblRecoveryPassHead);
            this.Controls.Add(this.btnRecord);
            this.Name = "Forget_Pass_Head";
            this.Text = "رمز عبور را فراموش کرده اید؟";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRecord;
        private System.Windows.Forms.Label lblRecoveryPassHead;
        private System.Windows.Forms.TextBox txtCodeHead;
    }
}
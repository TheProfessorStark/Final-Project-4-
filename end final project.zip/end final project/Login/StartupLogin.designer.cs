﻿namespace UNI_TEST
{
    partial class StartupLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStudent = new System.Windows.Forms.Button();
            this.btnProfessor = new System.Windows.Forms.Button();
            this.btnHead = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnStudent
            // 
            this.btnStudent.Location = new System.Drawing.Point(182, 228);
            this.btnStudent.Name = "btnStudent";
            this.btnStudent.Size = new System.Drawing.Size(118, 36);
            this.btnStudent.TabIndex = 0;
            this.btnStudent.Text = "دانشجو";
            this.btnStudent.UseVisualStyleBackColor = true;
            // 
            // btnProfessor
            // 
            this.btnProfessor.Location = new System.Drawing.Point(182, 186);
            this.btnProfessor.Name = "btnProfessor";
            this.btnProfessor.Size = new System.Drawing.Size(118, 36);
            this.btnProfessor.TabIndex = 0;
            this.btnProfessor.Text = "استاد";
            this.btnProfessor.UseVisualStyleBackColor = true;
            // 
            // btnHead
            // 
            this.btnHead.Location = new System.Drawing.Point(182, 144);
            this.btnHead.Name = "btnHead";
            this.btnHead.Size = new System.Drawing.Size(118, 36);
            this.btnHead.TabIndex = 0;
            this.btnHead.Text = "مدیر گروه";
            this.btnHead.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(12, 402);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(118, 36);
            this.btnExit.TabIndex = 0;
            this.btnExit.Text = "خروج";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // FormLogIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 450);
            this.Controls.Add(this.btnHead);
            this.Controls.Add(this.btnProfessor);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnStudent);
            this.Name = "FormLogIn";
            this.Text = "Log In";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnStudent;
        private System.Windows.Forms.Button btnProfessor;
        private System.Windows.Forms.Button btnHead;
        private System.Windows.Forms.Button btnExit;
    }
}


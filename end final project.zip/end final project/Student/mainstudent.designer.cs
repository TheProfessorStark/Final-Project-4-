﻿using System.Windows.Forms;

namespace WindowsFormsApp2
{
    partial class mainstudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Sbt = new System.Windows.Forms.Button();
            this.btn_showC = new System.Windows.Forms.Button();
            this.bnt_stat = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Sbt
            // 
            this.btn_Sbt.Location = new System.Drawing.Point(-16, -15);
            this.btn_Sbt.Name = "btn_Sbt";
            this.btn_Sbt.Size = new System.Drawing.Size(201, 102);
            this.btn_Sbt.TabIndex = 0;
            this.btn_Sbt.Text = "دروس ارایه شده";
            this.btn_Sbt.UseVisualStyleBackColor = true;
            // 
            // btn_showC
            // 
            this.btn_showC.Location = new System.Drawing.Point(-16, -15);
            this.btn_showC.Name = "btn_showC";
            this.btn_showC.Size = new System.Drawing.Size(205, 107);
            this.btn_showC.TabIndex = 0;
            this.btn_showC.Text = "مشاهده یا حذف";
            this.btn_showC.UseVisualStyleBackColor = true;
            // 
            // bnt_stat
            // 
            this.bnt_stat.Location = new System.Drawing.Point(-16, -17);
            this.bnt_stat.Name = "bnt_stat";
            this.bnt_stat.Size = new System.Drawing.Size(212, 98);
            this.bnt_stat.TabIndex = 0;
            this.bnt_stat.Text = "اخرین وضعیت تحصیلی";
            this.bnt_stat.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Location = new System.Drawing.Point(613, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(187, 449);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_Sbt);
            this.panel2.Location = new System.Drawing.Point(6, 86);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(178, 70);
            this.panel2.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btn_showC);
            this.panel3.Location = new System.Drawing.Point(6, 162);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(178, 77);
            this.panel3.TabIndex = 3;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.bnt_stat);
            this.panel4.Location = new System.Drawing.Point(6, 245);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(178, 81);
            this.panel4.TabIndex = 4;
            // 
            // mainstudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Name = "mainstudent";
            this.Text = "mainstudent";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Button btn_Sbt;
        private Button btn_showC;
        private Button bnt_stat;
        private Panel panel1;
        private Panel panel4;
        private Panel panel2;
        private Panel panel3;
    }
}
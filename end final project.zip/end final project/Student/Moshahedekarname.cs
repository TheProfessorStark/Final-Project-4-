using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Moshahedekarname : Form
    {
        public Moshahedekarname()
        {
            InitializeComponent();
        }
    }
}